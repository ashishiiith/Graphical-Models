#Author: Ashish Jain
#Course: CMPSCI 688 (Probabilistic Graphical Models)
#This script loads the data file for bayes net and learns the joint probabilities.
#How to run this program?: python bayesNet.py <arg1> <arg2> 
#arg1: path of training file. arg2: path of test file 

'''
Output: 
Question 4:  It will output CPTs for A, BP, HD, HR for the given training file
Question 5:  Output for the two Queries for the given training file
Question 6:  Classification output for the given training and test file
'''

import sys
import os
import itertools

""" stores values a particular variable can take """
variable_values = {} 
""" stores order in which variable is read from file """
variable_index = [] 
""" stores parent-child relationship """ 
graph = {}          
""" main structure which contains counts corresponding to each child-parent setting """
node_count = {}     


def initialize():


    #initializing values associated with each variable
    global variable_values
    variable_values['A'] = ['1', '2', '3']
    variable_values['G'] = ['1', '2']
    variable_values['CP'] = ['1', '2', '3', '4']
    variable_values['BP'] = ['1', '2']
    variable_values['CH'] = ['1', '2']
    variable_values['ECG'] = ['1', '2']
    variable_values['HR'] = ['1', '2']
    variable_values['EIA'] = ['1', '2']
    variable_values['HD'] = ['1', '2']
   
    #initializing graph with child:parent relations    
    global graph
    graph['G'] = []
    graph['A'] = []
    graph['BP'] = ['G']
    graph['CH'] = ['G', 'A']
    graph['HD'] = ['BP','CH']
    graph['CP'] = ['HD']
    graph['EIA'] = ['HD']
    graph['ECG'] = ['HD']
    graph['HR'] = ['A', 'HD']


    #defining order in which variables from data files would be read
    global variable_index
    variable_index = ['A', 'G', 'CP', 'BP', 'CH', 'ECG', 'HR', 'EIA', 'HD']

    global node_count   
    for variable in variable_index:
        node_count[variable] = {}
        parents = get_parents(variable)
        if len(parents) == 0:
            for values in variable_values[variable]:
                node_count[variable][values] = 0
        else:
           list_parents = []

           for parent in parents:
                list_parents.append(variable_values[parent])
           
           for pval in itertools.product(*list_parents):
                node_count[variable][pval] = 0
                for nval in variable_values[variable]:
                    node_count[variable][(nval,)+pval] = 0 

def get_variable(var):
    
    #returns variable for the given index of the variable.
    return variable_index[var]

def get_parents(var):

    #returns parents for a given random variable. 
    return graph[var]


def compute_counts(data):

    '''
        stores the count for random variables which will be used for computing joint and conditional probabilities
    '''
    global node_count
    for variable, val in data.items():
    
        parents = get_parents(variable)
        if len(parents) == 0:
            node_count[variable][val] += 1
        else:
            pval = tuple([data[parent] for parent in parents])
            node_count[variable][pval] += 1
            node_count[variable][(data[variable],)+pval]+=1         

def learn_graph():

    '''
        traverses the graph and learn the dependencies and store variable counts for a given training file.
    '''

    lines =  open(sys.argv[1], "r").readlines()
    
    for index in xrange(0, len(lines), 1):
        data = {}
        tokens = lines[index].strip().split(",")
        for i in xrange(0, len(tokens)):
            data[variable_index[i]] = tokens[i]
        compute_counts(data)        

def computeCPT(variable):

    '''
        for a given random variable it compute CPT
    '''

    parents = get_parents(variable)
        
    if len(parents) == 0:
        total_count = 0
        for key, val in node_count[variable].items():
            total_count += val
        check = 0 
        for values in variable_values[variable]:
        
            print variable + " " + str(values) + " " + str((node_count[variable][values]/(total_count*1.0)))
    else:
        list_parents=[]
        for parent in parents:
            list_parents.append(variable_values[parent])
        for pval in itertools.product(*list_parents):
            for nval in variable_values[variable]:
                print variable + " " + str((nval,)+pval) + " " + str(float(node_count[variable][(nval,)+pval]/(1.0*node_count[variable][pval])))

def solveQuery(query):

    '''
        Solve a given query.
    '''
    probability = 1.0
    for variable, parents in graph.items():
  
        if len(parents) == 0:    
            total_count = 0
            for key, val in node_count[variable].items():
                total_count += val
            probability*=float(node_count[variable][query[variable]]/(total_count*1.0))
        else:
            pval = tuple([query[parent] for parent in parents])
            probability*=float(node_count[variable][(query[variable],)+pval]/(1.0*node_count[variable][pval]))
    return probability

def findQuery():

    """ Solving the first query for CH=Low"""

    Query11 = {'A': '2', 'G':'2', 'CH':'1', 'CP':'4', 'BP' : '1', 'ECG' : '1', 'HR' : '1', 'EIA' : '1', 'HD' : '1'} 
    numerator = solveQuery(Query11)
    Query12 = {'A': '2', 'G':'2', 'CH':'2', 'CP':'4', 'BP' : '1', 'ECG' : '1', 'HR' : '1', 'EIA' : '1', 'HD' : '1'}
    denominator =  solveQuery(Query12)
    print "Solving the first query for CH=Low: " + str(float(numerator/(numerator+denominator)))

    """ Solving the second query for BP=Low """

    numerator=0.0
    denominator=0.0
    Query2 = {'A': '2', 'CH':'2', 'CP':'1', 'BP' : '1', 'ECG' : '1', 'HR' : '2', 'EIA' : '2', 'HD' : '1'}
    for value in variable_values['G']:
        Query2['G'] = value
        numerator+=solveQuery(Query2)
    for bp in variable_values['G']:
        for g in variable_values['BP']:
            Query2['BP'] = bp
            Query2['G'] = g
            denominator+=solveQuery(Query2)
    print "Solving the second query for BP=Low: " + str(float(numerator/denominator))

def classification():

   '''
        For a given train and test file, this function computes the correct and total instances.
   '''

   lines =  open(sys.argv[2], "r").readlines()
 
   correct = 0
   total = 0
   for index in xrange(0, len(lines), 1): 
        
        data = {}       
        tokens = lines[index].strip().split(",")
        true_class = tokens[8]
        for i in xrange(0, len(tokens)):
            data[variable_index[i]] = tokens[i]
        data['HD'] = '1'
        prob1 = solveQuery(data)
        data['HD'] = '2'
        prob2 = solveQuery(data)
        if prob1 >= prob2 and true_class =='1':
            correct+=1
        elif prob2 > prob1 and true_class == '2':
            correct+=1
        total+=1
   print "Classification for " + sys.argv[2]
   print "correct: " + str(correct)
   print "total: " +  str(total)

def main():

    initialize()
    learn_graph()
    print "\nQuestion 4: CPT Output\n" 
    computeCPT('A')
    print
    computeCPT('BP')
    print
    computeCPT('HD')
    print
    computeCPT('HR')

    print "\nQuestion5: Probability Queries\n"
    findQuery()

    print "\nQuestion6: Classification\n"
    classification()
    print

if __name__ == "__main__":
    main()
